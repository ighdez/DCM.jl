using DCM
using Test

include("test_expressions.jl")
# include("test_logitmodel.jl")